
package com.d17b.masa_daily;
import static android.content.ContentValues.TAG;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.d17b.masa_daily.ml.FishpakV1;

import org.tensorflow.lite.DataType;
import org.tensorflow.lite.support.image.TensorImage;
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.HashMap;

public class classificationPage extends AppCompatActivity {
    private ImageView imgView;
    private Button select, predict;
    private TextView result;
    private Bitmap img,img2;

    // Constants for image resizing
    private static final int TARGET_WIDTH = 224; // Adjust as needed
    private static final int TARGET_HEIGHT = 224; // Adjust as needed

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classification_page);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        imgView = findViewById(R.id.imageView);
        select = findViewById(R.id.button);
        predict = findViewById(R.id.button2);
        result = findViewById(R.id.textView);

        select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");

                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent,100);
                /*
                // Check if there is an app that can handle the intent
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(Intent.createChooser(intent, "Select Image"), 100);
                } else {
                    // Handle the case where no app can handle the intent
                    // You can show a message to the user or take alternative action.
                }
                 */
            }
        });

        predict.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!loadCheck()){
                    return;
                }

                img2 = Bitmap.createScaledBitmap(img,224,224,true);

                try {
                    FishpakV1 model = FishpakV1.newInstance(getApplicationContext());

                    TensorBuffer inputFeature0 = TensorBuffer.createFixedSize(new int[]{1, 224, 224, 3}, DataType.FLOAT32);

                    TensorImage tensorImage = new TensorImage(DataType.FLOAT32);
                    tensorImage.load(img2);
                    ByteBuffer byteBuffer = tensorImage.getBuffer();


                    // Creates inputs for reference.
                    inputFeature0.loadBuffer(byteBuffer);

                    // Runs model inference and gets result.
                    FishpakV1.Outputs outputs = model.process(inputFeature0);
                    TensorBuffer outputFeature0 = outputs.getOutputFeature0AsTensorBuffer();

                    // Releases model resources if no longer used.
                    model.close();

                    Log.d(TAG, "Tag1: "+Arrays.toString(outputFeature0.getFloatArray()));

                    float[] result_output = outputFeature0.getFloatArray();


                    HashMap<Integer, String> classLabels = new HashMap<>();
                    classLabels.put(0, "Catla");
                    classLabels.put(1, "Cyrpinus Carpio");
                    classLabels.put(2, "Grass Carp");
                    classLabels.put(3, "Mori");
                    classLabels.put(4, "Rohu");
                    classLabels.put(5, "Silver");

// Find the index with the highest probability
                    int maxIndex = 0;
                    double maxProbability = result_output[0];

                    for (int i = 1; i < result_output.length; i++) {
                        if (result_output[i] > maxProbability) {
                            maxIndex = i;
                            maxProbability = result_output[i];
                        }
                    }

// Get the class name with the highest probability
                    String predictedClassName = classLabels.get(maxIndex);

                    Log.i(TAG, "results :"+predictedClassName+result_output.toString());

                    result.setText(predictedClassName);

                } catch (IOException e) {
                    // TODO Handle the exception
                }
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 100 && resultCode == RESULT_OK) {
            if (data != null) {
                Uri uri = data.getData();
                try {
                    img = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
                    // Resize the image to the specific dimensions
                    img = resizeBitmap(img, TARGET_WIDTH, TARGET_HEIGHT);
                    imgView.setImageBitmap(img);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // Resize a bitmap to the specified width and height
    private Bitmap resizeBitmap(Bitmap bitmap, int width, int height) {
        return Bitmap.createScaledBitmap(bitmap, width, height, true);
    }

    private boolean loadCheck(){
        if (img2 == null) {
            Toast.makeText(this, "Please select an image first", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
