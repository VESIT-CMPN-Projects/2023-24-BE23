package com.d17b.masa_daily;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class menu_activity extends AppCompatActivity {
    private Button classify,catchLog,weather,pfzMap;
    private TextView Username_text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        classify = findViewById(R.id.button_classify);
        catchLog = findViewById(R.id.button_catch_log);
        Username_text = findViewById(R.id.username_text);
        weather = findViewById(R.id.button_weather);
        pfzMap = findViewById(R.id.button_fishing_zone);

        Username_text.setText(login_activity.Global.User_name);

        classify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(menu_activity.this,classificationPage.class);
                startActivity(intent);
            }
        });
        catchLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(menu_activity.this,CatchLogs.class);
                startActivity(intent);
            }
        });
        weather.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(menu_activity.this, WeatherMap.class);
                startActivity(intent);
            }
        });
        pfzMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(menu_activity.this, pfzMap.class);
                startActivity(intent);
            }
        });
    }
}