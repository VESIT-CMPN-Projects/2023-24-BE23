package com.d17b.masa_daily;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.ListResult;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

public class DisplayFoldersActivity extends AppCompatActivity implements FolderAdapter.OnFolderClickListener {

    private RecyclerView recyclerView;
    private FolderAdapter folderAdapter;
    private List<String> folderNames;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_folders);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);


        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        folderNames = new ArrayList<>();
        folderAdapter = new FolderAdapter(folderNames, this); // Pass this activity as the click listener
        recyclerView.setAdapter(folderAdapter);

        // Get the reference to the root directory in Firebase Storage
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference rootRef = storage.getReference().child(login_activity.Global.User_name);

        // List all items (folders) directly under the root directory
        rootRef.listAll().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                ListResult result = task.getResult();
                List<StorageReference> items = result.getPrefixes(); // Get list of folder references

                // Loop through the list of folder references and add their names to the list
                for (StorageReference folderRef : items) {
                    String folderName = folderRef.getName();
                    Log.d(TAG, "Folder: " + folderName);
                    folderNames.add(folderName);
                }
                // Notify the adapter that the data set has changed
                folderAdapter.notifyDataSetChanged();
            } else {
                Log.e(TAG, "Error listing folders", task.getException());
                Toast.makeText(DisplayFoldersActivity.this, "Failed to retrieve folder list", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onFolderClick(String folderName) {
        // Handle folder click here
        Toast.makeText(this, "Clicked folder: " + folderName, Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(DisplayFoldersActivity.this,dispaly_Images.class);
        intent.putExtra("Folder_Name", folderName);

        startActivity(intent);

    }
}
