package com.d17b.masa_daily;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.ListResult;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

public class dispaly_Images extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ImageAdapter imageAdapter;
    private String Folder_Name;
    private List<ImageModel> imageList;

    private FirebaseAuth mAuth; // Firebase Authentication instance

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dispaly_images);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        mAuth = FirebaseAuth.getInstance(); // Initialize Firebase Authentication
        FirebaseUser currentUser = mAuth.getCurrentUser();

        // Sign in anonymously
        mAuth.signInAnonymously().addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    // Authentication successful
                    Log.d(TAG, "signInAnonymously:success");
                    Toast.makeText(dispaly_Images.this, "Authentication success.", Toast.LENGTH_SHORT).show();
                } else {
                    // Authentication failed
                    Log.w(TAG, "signInAnonymously:failure", task.getException());
                    Toast.makeText(dispaly_Images.this, "Authentication failed.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Get the Intent that started this activity
        Intent intent = getIntent();
        // Retrieve the variable using Intent.getStringExtra()
        Folder_Name = intent.getStringExtra("Folder_Name");

        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2)); // Assuming you want a grid layout
        imageList = new ArrayList<>();
        imageAdapter = new ImageAdapter(imageList);
        recyclerView.setAdapter(imageAdapter);

        // Retrieve images from Firebase Storage
        retrieveImagesFromStorage();
    }

    private void retrieveImagesFromStorage() {
        FirebaseStorage storage = FirebaseStorage.getInstance();
        String imgPath = login_activity.Global.User_name + "/" + Folder_Name;
        Log.d("Image path", imgPath);
        StorageReference storageReference = storage.getReference().child(imgPath);

        storageReference.listAll().addOnSuccessListener(listResult -> {
            for (StorageReference item : listResult.getItems()) {
                item.getDownloadUrl().addOnSuccessListener(uri -> {
                    // Create an ImageModel object with the image URI and add it to the list
                    ImageModel image = new ImageModel(uri.toString());
                    imageList.add(image);
                    // Notify the adapter that the data set has changed
                    imageAdapter.notifyDataSetChanged();
                }).addOnFailureListener(exception -> {
                    // Handle any errors that may occur while fetching the download URL
                    exception.printStackTrace();
                });
            }
        }).addOnFailureListener(exception -> {
            // Handle any errors that may occur while listing files in the storage bucket
            exception.printStackTrace();
        });
        Log.d("Image URLs", imageList.toString());
    }
}
