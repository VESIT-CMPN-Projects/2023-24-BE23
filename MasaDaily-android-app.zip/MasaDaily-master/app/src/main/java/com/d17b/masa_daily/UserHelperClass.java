package com.d17b.masa_daily;


public class UserHelperClass {

    String name, username, phoneNo, passcode;

    public UserHelperClass(){

    }

    public UserHelperClass(String name,String username, String phoneNo, String passcode){
        this.name = name;
        this.username = username;
        this.phoneNo = phoneNo;
        this.passcode = passcode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getPasscode() {
        return passcode;
    }

    public void setPasscode(String passcode) {
        this.passcode = passcode;
    }
}


