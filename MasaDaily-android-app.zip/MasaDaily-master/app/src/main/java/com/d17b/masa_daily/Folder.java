package com.d17b.masa_daily;

public class Folder {
    private String folderName;
    private String date;

    public Folder() {
        // Required empty public constructor
    }

    public Folder(String folderName, String date) {
        this.folderName = folderName;
        this.date = date;
    }

    public String getFolderName() {
        return folderName;
    }

    public void setFolderName(String folderName) {
        this.folderName = folderName;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
