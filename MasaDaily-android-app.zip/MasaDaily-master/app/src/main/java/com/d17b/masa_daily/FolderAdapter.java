package com.d17b.masa_daily;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
public class FolderAdapter extends RecyclerView.Adapter<FolderAdapter.FolderViewHolder> {

    private List<String> folderNames;
    private OnFolderClickListener onFolderClickListener; // Interface instance

    // Interface for click listener
    public interface OnFolderClickListener {
        void onFolderClick(String folderName);
    }

    // Constructor with the click listener interface
    public FolderAdapter(List<String> folderNames, OnFolderClickListener listener) {
        this.folderNames = folderNames;
        this.onFolderClickListener = listener;
    }

    @NonNull
    @Override
    public FolderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_folder, parent, false);
        return new FolderViewHolder(view, onFolderClickListener); // Pass onFolderClickListener to ViewHolder
    }

    @Override
    public void onBindViewHolder(@NonNull FolderViewHolder holder, int position) {
        String folderName = folderNames.get(position);
        holder.folderNameTextView.setText(folderName);
    }

    @Override
    public int getItemCount() {
        return folderNames.size();
    }

    // ViewHolder class
    public class FolderViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView folderNameTextView;
        private OnFolderClickListener folderClickListener; // Interface instance

        public FolderViewHolder(@NonNull View itemView, OnFolderClickListener listener) {
            super(itemView);
            folderNameTextView = itemView.findViewById(R.id.folder_name_text_view);
            folderClickListener = listener; // Assign the listener
            itemView.setOnClickListener(this); // Set click listener to the itemView
        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            if (position != RecyclerView.NO_POSITION && folderClickListener != null) {
                String folderName = folderNames.get(position);
                folderClickListener.onFolderClick(folderName); // Invoke the click listener method
            }
        }
    }
}
